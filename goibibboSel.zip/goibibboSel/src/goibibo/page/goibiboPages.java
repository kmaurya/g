package goibibo.page;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.concurrent.TimeUnit;

import goibibo.test.goibiboTests;

import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.io.SAXReader;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class goibiboPages {
	WebDriver driver;
	goibiboTests gbt;
	goibiboPages gbp;
	File src;
	SAXReader saxReader;
	Document document;

	@BeforeClass
	public void initTestEle() {
		System.setProperty("webdriver.chrome.driver","D:\\Adesh\\Advanced Selenium Libs\\chrome\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.get("https://www.goibibo.com/");
		System.out.println("Starting Test");
		gbt = PageFactory.initElements(driver, goibiboTests.class);
		gbp = new goibiboPages();
		gbp.sleep(1000);
		src = new File("./src/reposit/TestData1.xml");
		FileInputStream fis;
		try {
			fis = new FileInputStream(src);
			saxReader = new SAXReader();
			document = saxReader.read(fis);
		} catch (FileNotFoundException | DocumentException e) {

			e.printStackTrace();
		}

	}

	@Test(priority = 1)
	public void testForDestination() {
		gbt.clickThis(document.selectSingleNode("//ibibo/home/roundTrip")
				.getText());
		gbt.typeThis(document.selectSingleNode("//ibibo/home/sourceCityValue")
				.getText(), document
				.selectSingleNode("//ibibo/home/sourceCity").getText());
		gbp.sleep(2000);
		gbt.typeThis(document.selectSingleNode("//ibibo/home/destCityVlue")
				.getText(), document.selectSingleNode("//ibibo/home/destCity")
				.getText());
		gbp.sleep(1000);
	}

	@Test(priority = 2)
	public void testForDate() {
		gbt.clickThis(document.selectSingleNode("//ibibo/home/day1").getText());
		gbp.sleep(3000);
		gbt.clickThis(document.selectSingleNode("//ibibo/home/dayVal")
				.getText());
		gbt.clickThis(document.selectSingleNode("//ibibo/home/day2").getText());
		gbt.clickThis(document.selectSingleNode("//ibibo/home/dayVal2")
				.getText());
		gbp.sleep(1000);
	}

	@AfterClass
	public void endindTask() {
		driver.quit();
		gbt = null;
	}

	@Test(priority = 2)
	public void testForSelectClss() {
		gbt.selectClass(document.selectSingleNode("//ibibo/home/classVal").getText(), document.selectSingleNode("//ibibo/home/class").getText());
		gbt.clickThis(document.selectSingleNode("//ibibo/home/goBtn").getText());
			}

	@Test(priority = 4)
	public void testForSetBtn() {
		gbt.clickThis(document.selectSingleNode("//ibibo/Book/bookBtn").getText());
		gbp.sleep(9000);
	}

	public void sleep(int timeForWait) {
		try {
			Thread.sleep(timeForWait);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
}